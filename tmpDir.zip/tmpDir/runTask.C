int runTask (TString runMode="",TString analysisMode="",TString inputName="",TString inputOptions="",TString softVersions="",TString analysisOptions="",TString taskOptions=""){

	runMode ="test";
	analysisMode ="local";
	//inputName ="Find;BasePath=/alice/data/2015/LHC15o/000246049/muon_calo_pass1/AOD/;FileName=AliAOD.root;";
	inputName ="~/AliAOD.root"
	inputOptions ="AOD";
	softVersions ="aliphysics=vAN-20160203-1";
	analysisOptions ="CENTR";
	taskOptions ="";

  gROOT->LoadMacro(gSystem->ExpandPathName("$TASKDIR/runTaskUtilities.C"));

  SetupAnalysis(runMode,analysisMode,inputName,inputOptions,softVersions,analysisOptions, "libPWGmuon.so AliAnalysisTaskUpsilon.cxx AddTaskUpsilon.C",". $ALICE_ROOT/include $ALICE_PHYSICS/include","");

// AliAnalysisAlien* plugin = static_cast<AliAnalysisAlien*>(AliAnalysisManager::GetAnalysisManager()->GetGridHandler()); // Uncomment it if you want to configure the plugin...

  Bool_t isMC = IsMC(inputOptions);

  AliAnalysisTaskUpsilon* taskMy = AddTaskUpsilon(isMC, "first");

// AliMuonEventCuts* eventCuts = BuildMuonEventCuts(map); // Pre-configured AliMuonEventCuts
// SetupMuonBasedTask(task,eventCuts,taskOptions,map); // Automatically setup "task" if it derives from AliVAnalysisMuon

  StartAnalysis(runMode,analysisMode,inputName,inputOptions);

  return 0;
}